
import numpy
bankingdatabase=numpy.load("bankingdatabase2player.npy")


#print(numpy.unique(bankingdatabase,return_counts=True))

for i in range(6):
    print(bankingdatabase[19,19,i,0])
